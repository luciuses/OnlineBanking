using ASP;

namespace ExtendedEditorFor.Models
{
    public class Employee
    {
        [HtmlProperties(Size = 5, MaxLength = 10)]
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}